package com.goodwy.dialer.helpers

import android.content.Context
import android.graphics.*
import android.provider.MediaStore
import android.util.Size
import com.goodwy.commons.helpers.isQPlus
import com.goodwy.dialer.R
import androidx.core.net.toUri
import androidx.core.graphics.createBitmap

class CallContactAvatarHelper(private val context: Context) {
    fun getCallContactAvatar(photoUri: String?, round: Boolean = true, width: Int = 0, height: Int = 0): Bitmap? {
        var bitmap: Bitmap? = null
        if (photoUri?.isNotEmpty() == true) {
            val photoUriParse = photoUri.toUri()
            try {
                val contentResolver = context.contentResolver
                bitmap = if (isQPlus()) {
                    if (round) {
                        val tmbSize = context.resources.getDimension(R.dimen.list_avatar_size).toInt()
                        contentResolver.loadThumbnail(photoUriParse, Size(tmbSize, tmbSize), null)
                    } else {
                        contentResolver.loadThumbnail(photoUriParse, Size(width, height), null)
                    }
                } else {
                    MediaStore.Images.Media.getBitmap(contentResolver, photoUriParse)
                }
                bitmap = if (round) getCircularBitmap(bitmap!!) else bitmap
            } catch (_: Exception) {
                return null
            }
        }
        return bitmap
    }

    fun getCircularBitmap(bitmap: Bitmap): Bitmap {
        val output = createBitmap(bitmap.width, bitmap.width)
        val canvas = Canvas(output)
        val paint = Paint()
        val rect = Rect(0, 0, bitmap.width, bitmap.height)
        val radius = bitmap.width / 2.toFloat()

        paint.isAntiAlias = true
        canvas.drawARGB(0, 0, 0, 0)
        canvas.drawCircle(radius, radius, radius, paint)
        paint.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        canvas.drawBitmap(bitmap, rect, rect, paint)
        return output
    }
}
