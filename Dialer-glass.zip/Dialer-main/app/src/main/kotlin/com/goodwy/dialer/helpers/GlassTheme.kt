package com.goodwy.dialer.helpers

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.cardview.widget.CardView
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import com.goodwy.dialer.R

object GlassTheme {
    /** Puts the aqua glass wallpaper behind [root] and makes system bars transparent with light icons. */
    fun applyWallpaper(activity: Activity, root: View) {
        if (!GLASS_UI) return
        root.setBackgroundResource(R.drawable.glass_wallpaper)
        activity.window.statusBarColor = Color.TRANSPARENT
        activity.window.navigationBarColor = Color.TRANSPARENT
        WindowCompat.getInsetsController(activity.window, root).apply {
            isAppearanceLightStatusBars = false
            isAppearanceLightNavigationBars = false
        }
    }

    /** Removes solid theme backgrounds so the wallpaper shows through. */
    fun clearSolid(vararg views: View) {
        if (!GLASS_UI) return
        views.forEach { it.setBackgroundColor(Color.TRANSPARENT) }
    }

    /**
     * Restyles every screen (settings, history, speed dial, ...) in glass:
     * solid backgrounds -> transparent, cards -> translucent glass with a rim, dark text -> white.
     */
    fun styleTree(view: View, depth: Int = 0) {
        if (!GLASS_UI) return
        when (view) {
            is CardView -> {
                view.setCardBackgroundColor(0x2EFFFFFF)
                view.cardElevation = 0f
                view.foreground = ContextCompat.getDrawable(view.context, R.drawable.glass_card_rim)
            }
            is TextView -> {
                val c = view.currentTextColor
                if (ColorUtils.calculateLuminance(c) < 0.5) {
                    view.setTextColor(ColorUtils.setAlphaComponent(Color.WHITE, Color.alpha(c)))
                }
            }
            is ViewGroup -> {
                if (depth <= 6 && view.background is ColorDrawable) view.setBackgroundColor(Color.TRANSPARENT)
            }
        }
        if (view is ViewGroup) {
            for (i in 0 until view.childCount) styleTree(view.getChildAt(i), depth + 1)
        }
    }
}
