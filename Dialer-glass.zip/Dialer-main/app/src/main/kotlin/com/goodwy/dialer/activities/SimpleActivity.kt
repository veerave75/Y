package com.goodwy.dialer.activities

import com.goodwy.commons.activities.BaseSimpleActivity
import android.graphics.Color
import android.view.ViewGroup
import com.goodwy.dialer.R
import com.goodwy.dialer.helpers.GLASS_UI
import com.goodwy.dialer.helpers.GlassTheme

open class SimpleActivity : BaseSimpleActivity() {
    override fun onResume() {
        super.onResume()
        if (GLASS_UI) {
            window.setBackgroundDrawableResource(R.drawable.glass_wallpaper)
            window.statusBarColor = Color.TRANSPARENT
            window.navigationBarColor = Color.TRANSPARENT
            val root = findViewById<ViewGroup>(android.R.id.content)
            root.post { GlassTheme.styleTree(root) }
            root.postDelayed({ GlassTheme.styleTree(root) }, 400)
        }
    }

    override fun getAppIconIDs() = arrayListOf(
        R.mipmap.ic_launcher,
        R.mipmap.ic_launcher_one,
        R.mipmap.ic_launcher_two,
        R.mipmap.ic_launcher_three,
        R.mipmap.ic_launcher_four,
        R.mipmap.ic_launcher_five,
        R.mipmap.ic_launcher_six,
        R.mipmap.ic_launcher_seven,
        R.mipmap.ic_launcher_eight,
        R.mipmap.ic_launcher_nine,
        R.mipmap.ic_launcher_ten,
        R.mipmap.ic_launcher_eleven
    )

    override fun getAppLauncherName() = getString(R.string.app_launcher_name)

    override fun getRepositoryName() = "Dialer"
}
